angular.module('Mine', [])

.controller('MineCtrl', function ($scope) {})
