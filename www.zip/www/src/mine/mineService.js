angular.module('Mine', [])

.service('mineService', function () {

})
